let a = 80;
function setup() {
  createCanvas(600, 600, SVG);
  angleMode(DEGREES);
  stroke(255);
  noLoop();
}

function draw() {
  background(0);
  let x1, y1, x2, y2, x3, y3, x4, y4;
  x1 = -a * cos(30);
  y1 = a * sin(30);
  x2 = a * cos(30);
  y2 = -a * sin(30);
  x3 = x1;
  y3 = y2;
  x4 = x2;
  y4 = y1;

  push();
  translate(width * 0.5, height * 0.5); 
  for (let i = 0; i < 6; i++) {
    push();
    rotate(i*60);
    translate(2 * a * cos(30), 0);
    beginShape();
    vertex(x1, y1);
    vertex(x2, y2);
    endShape();
    beginShape();
    vertex(x3, y3);
    vertex(x4, y4);
    endShape();
    pop();
  }
  pop();
  save("motif.svg");
}
